-- Chay SAU khi da chay file QuanLySinhVien.sql (hoac neu database da co san).
USE QuanLySinhVien;
GO
-- Dat mat khau that de dang nhap duoc (du lieu mau, mat khau luu dang van ban de don gian cho do an)
UPDATE NguoiDung SET MatKhau = '123456' WHERE TenDangNhap IN ('admin', 'gv001', 'sv001');
-- Sua loi font chu o mon Xac suat thong ke (thieu tien to N)
UPDATE MonHoc SET TenMon = N'Xác suất thống kê' WHERE MaMon = 'XSTK01';
GO
SELECT TenDangNhap, MatKhau, HoTen, VaiTro FROM NguoiDung;
SELECT MaMon, TenMon, SoTinChi FROM MonHoc;
