﻿CREATE DATABASE QuanLySinhVien;
GO

USE QuanLySinhVien;
GO
-- KHOA
CREATE TABLE Khoa (
    MaKhoa VARCHAR(10) PRIMARY KEY,
    TenKhoa NVARCHAR(100)
);
-- LOP
CREATE TABLE Lop (
    MaLop VARCHAR(10) PRIMARY KEY,
    TenLop NVARCHAR(100),
    MaKhoa VARCHAR(10),
    FOREIGN KEY (MaKhoa) REFERENCES Khoa(MaKhoa)
);
-- SINHVIEN
CREATE TABLE SinhVien (
    MaSV VARCHAR(10) PRIMARY KEY,
    HoTen NVARCHAR(100),
    NgaySinh DATE,
    GioiTinh NVARCHAR(10),
    DiaChi NVARCHAR(200),
    MaLop VARCHAR(10),
    FOREIGN KEY (MaLop) REFERENCES Lop(MaLop)
);
--USER
CREATE TABLE NguoiDung (
    MaNguoiDung INT IDENTITY(1,1) PRIMARY KEY,
    TenDangNhap VARCHAR(50) UNIQUE,
    MatKhau VARCHAR(255),
    HoTen NVARCHAR(100),
    VaiTro NVARCHAR(30)
);
--MONHOC
CREATE TABLE MonHoc (
    MaMon VARCHAR(10) PRIMARY KEY,
    TenMon NVARCHAR(100),
    SoTinChi INT 
);
--KETQUA
CREATE TABLE KetQua (
    MaSV VARCHAR(10),
    MaMon VARCHAR(10),
    DiemQuaTrinh DECIMAL(4,2),
    DiemThi DECIMAL(4,2),
    PRIMARY KEY (MaSV, MaMon),
    FOREIGN KEY (MaSV)
        REFERENCES SinhVien(MaSV),

    FOREIGN KEY (MaMon)
        REFERENCES MonHoc(MaMon),
    CHECK (
        DiemQuaTrinh IS NULL
        OR DiemQuaTrinh BETWEEN 0 AND 10
    ),
    CHECK (
        DiemThi IS NULL
        OR DiemThi BETWEEN 0 AND 10
    )
);
-- Them KHOA
INSERT INTO Khoa VALUES
('CNTT', N'Công nghệ thông tin'),
('QTKD', N'Quản trị kinh doanh'),
('KT', N'Kế toán'),
('DL', N'Du lịch lữ hành'),
('NNA', N'Ngôn ngữ Anh');

-- Them LOP
INSERT INTO Lop VALUES
('CNTT01', N'Công nghệ thông tin 01', 'CNTT'),
('CNTT02', N'Công nghệ thông tin 02', 'CNTT'),
('QTKD01', N'Quản trị kinh doanh 01', 'QTKD'),
('KT01', N'Kế toán 01', 'KT'),
('DL01', N'Du lịch lữ hành 01', 'DL'),
('NNA03', N'Ngôn ngữ Anh 03', 'NNA');

-- Them SINHVIEN
INSERT INTO SinhVien
(MaSV, HoTen, NgaySinh, GioiTinh,
 DiaChi, MaLop)
VALUES
('SV001', N'Nguyễn Mạnh Tiến', '2008-03-20',
 N'Nam', N'Hà Nội', 'CNTT01'),
 ('SV002', N'Liễu Như Yên', '2005-08-10',
 N'Nữ', N'Đăk Lăk', 'NNA03'),
 ('SV003', N'Nghiêm Sơn Hoàng', '2009-01-13',
 N'Nam', N'Hải Phòng', 'CNTT02'),
 ('SV004', N'Lâm Uyển Nhi', '2006-02-05',
 N'Nữ', N'Hưng Yên', 'DL01'),
 ('SV005', N'Lưu Chí Bình', '2005-07-09',
 N'Nam', N'Thanh Hoá', 'KT01'),
 ('SV006', N'Phạm Lâm Mạnh', '2006-11-02',
 N'Nam', N'Nam Định', 'CNTT01'),
 ('SV007', N'Lê Ngọc Quyên', '2007-12-30',
 N'Nữ', N'Hà Nội', 'KT01'),
('SV008', N'Nguyễn Minh Anh', '2005-01-15',
 N'Nữ', N'Hà Nội', 'CNTT01'),
('SV009', N'Trần Quốc Bảo', '2005-03-20',
 N'Nam', N'Hải Phòng', 'CNTT02'),
('SV010', N'Lê Hoàng Nam', '2005-06-12',
 N'Nam', N'Đà Nẵng', 'CNTT01'),
('SV011', N'Phạm Ngọc Hà', '2005-08-25',
 N'Nữ', N'Bắc Ninh', 'CNTT02'),
('SV012', N'Vũ Đức Huy', '2005-04-10',
 N'Nam', N'Nam Định', 'CNTT01'),
('SV013', N'Đặng Thu Trang', '2005-09-17',
 N'Nữ', N'Hưng Yên', 'CNTT02'),
('SV014', N'Bùi Thành Công', '2005-02-08',
 N'Nam', N'Thái Bình', 'DL01'),
('SV015', N'Đỗ Khánh Linh', '2005-11-22',
 N'Nữ', N'Ninh Bình', 'DL01'),
('SV016', N'Ngô Tuấn Kiệt', '2005-07-14',
 N'Nam', N'Thanh Hóa', 'DL01'),
('SV017', N'Hoàng Phương Thảo', '2005-12-05',
 N'Nữ', N'Nghệ An', 'DL01'),
('SV018', N'Dương Gia Hưng', '2005-05-19',
 N'Nam', N'Hà Tĩnh', 'KT01'),
('SV019', N'Phan Thị Mai', '2005-10-03',
 N'Nữ', N'Quảng Ninh', 'KT01'),
('SV020', N'Võ Anh Tuấn', '2005-01-28',
 N'Nam', N'Bắc Giang', 'KT01'),
('SV021', N'Đinh Ngọc Yến', '2005-06-30',
 N'Nữ', N'Hải Dương', 'KT01'),
('SV022', N'Lý Minh Quân', '2005-03-11',
 N'Nam', N'Nam Định', 'NNA03'),
('SV023', N'Tạ Bảo Ngọc', '2005-08-16',
 N'Nữ', N'Hà Nội', 'NNA03'),
('SV024', N'Nguyễn Hoàng Phúc', '2005-02-24',
 N'Nam', N'Đà Nẵng', 'NNA03'),
('SV025', N'Trần Mỹ Duyên', '2005-09-09',
 N'Nữ', N'Hải Phòng', 'NNA03'),
('SV026', N'Lê Thanh Tùng', '2005-04-21',
 N'Nam', N'Thái Nguyên', 'CNTT01'),
('SV027', N'Phạm Thùy Dung', '2005-07-07',
 N'Nữ', N'Phú Thọ', 'CNTT02'),
('SV028', N'Vũ Quang Minh', '2005-12-18',
 N'Nam', N'Lào Cai', 'CNTT01'),
('SV029', N'Đặng Hải Yến', '2005-05-13',
 N'Nữ', N'Yên Bái', 'CNTT02'),
('SV030', N'Bùi Nhật Long', '2005-10-26',
 N'Nam', N'Quảng Ninh', 'DL01'),
('SV031', N'Đỗ Ngọc Ánh', '2005-01-09',
 N'Nữ', N'Ninh Bình', 'DL01'),
('SV032', N'Ngô Đức Anh', '2005-06-17',
 N'Nam', N'Thanh Hóa', 'KT01'),
('SV033', N'Hoàng Kim Chi', '2005-11-01',
 N'Nữ', N'Nghệ An', 'KT01'),
('SV034', N'Dương Thành Đạt', '2005-03-29',
 N'Nam', N'Quảng Nam', 'NNA03'),
('SV035', N'Phan Thùy Linh', '2005-08-12',
 N'Nữ', N'Bình Định', 'NNA03'),
('SV036', N'Võ Minh Khang', '2005-04-06',
 N'Nam', N'Đồng Nai', 'CNTT01'),
('SV037', N'Đinh Bảo Trân', '2005-09-23',
 N'Nữ', N'Cần Thơ', 'CNTT02');

 --Them USER
 INSERT INTO NguoiDung
(TenDangNhap, MatKhau, HoTen, VaiTro)
VALUES
('admin', 'HASH_MAT_KHAU_ADMIN',
 N'Quản trị viên', N'Admin'),

('gv001', 'HASH_MAT_KHAU_GV',
 N'Nguyễn Văn Giảng', N'GiangVien'),

('sv001', 'HASH_MAT_KHAU_SV',
 N'Nguyễn Mạnh Tiến', N'SinhVien');

 --Them MONHOC
 INSERT INTO MonHoc (MaMon, TenMon, SoTinChi)
VALUES
('SQL01', N'Cơ sở dữ liệu', 3),
('JAVA01', N'Lập trình Java', 4),
('WEB01', N'Lập trình Web', 4),
('CTDL01', N'Cấu trúc dữ liệu', 2),
('HA01', N'Tiếng Anh', 2),
('XSTK01', N'Xác suất thống kê', 4);

--Them KETQUA
INSERT INTO KetQua
(MaSV, MaMon, DiemQuaTrinh, DiemThi)
VALUES
('SV001', 'SQL01', 8.0, 9.0),
('SV001', 'JAVA01', 7.5, 8.0),
('SV002', 'SQL01', 9.0, 8.5),
('SV002', 'WEB01', 8.0, 9.0),
('SV003', 'JAVA01', 6.5, 7.0),
('SV004', 'SQL01', 4.0, 4.5),
('SV005', 'CTDL01', 7.0, 6.5),
('SV006', 'CTDL01', 9.0, 8.5),
('SV006', 'HA01', 9.0, 9.5),
('SV007', 'HA01', 8.0, 7.5),
('SV007', 'XSTK01', 7.0, 8.5),
('SV008', 'SQL01', 8.0, 7.5),
('SV008', 'JAVA01', 7.5, 8.0),
('SV009', 'WEB01', 7.0, 8.0),
('SV010', 'SQL01', 8.5, 9.0),
('SV010', 'XSTK01', 8.0, 8.0),
('SV011', 'HA01', 6.0, 7.5),
('SV012', 'CTDL01', 7.0, 7.5),
('SV012', 'JAVA01', 8.0, 8.5),
('SV013', 'WEB01', 7.5, 8.0),
('SV014', 'SQL01', 7.0, 7.5),
('SV014', 'HA01', 9.0, 8.5),
('SV015', 'XSTK01', 4.0, 5.5),
('SV016', 'SQL01', 9.0, 8.5),
('SV016', 'JAVA01', 8.0, 7.5),
('SV017', 'CTDL01', 7.5, 8.0),
('SV018', 'WEB01', 8.5, 9.0),
('SV018', 'XSTK01', 8.0, 8.5),
('SV019', 'SQL01', 8.0, 8.5),
('SV020', 'JAVA01', 8.5, 9.0),
('SV020', 'WEB01', 5.0, 5.5),
('SV021', 'HA01', 8.0, 8.5),
('SV022', 'SQL01', 8.5, 9.0),
('SV022', 'CTDL01', 7.5, 8.0),
('SV023', 'XSTK01', 9.0, 9.5),
('SV024', 'JAVA01', 8.5, 9.0),
('SV024', 'WEB01', 8.0, 8.5),
('SV025', 'HA01', 9.0, 9.0),
('SV026', 'JAVA01', 8.0, 8.5),
('SV026', 'XSTK01', 9.0, 9.5),
('SV027', 'CTDL01', 7.5, 8.0),
('SV028', 'WEB01', 8.5, 9.0),
('SV028', 'SQL01', 8.0, 8.5),
('SV029', 'HA01', 7.5, 8.0),
('SV030', 'SQL01', 8.0, 8.5),
('SV030', 'JAVA01', 9.0, 9.5),
('SV031', 'WEB01', 8.0, 8.5),
('SV032', 'SQL01', 8.5, 9.0),
('SV032', 'JAVA01', 7.5, 8.0),
('SV033', 'HA01', 9.0, 9.5),
('SV034', 'WEB01', 9.0, 9.0),
('SV034', 'XSTK01', 7.5, 8.0),
('SV035', 'CTDL01', 7.0, 7.5),
('SV036', 'SQL01', 7.5, 8.0),
('SV036', 'JAVA01', 8.0, 8.5),
('SV037', 'HA01', 8.0, 8.5);

