# Xây dựng phần mềm quản lý sinh viên bằng Java

Đồ án Java: phần mềm quản lý sinh viên (Java Swing + JDBC + SQL Server).

## Chức năng
- Đăng nhập (kiểm tra tài khoản trong bảng `NguoiDung`)
- Quản lý sinh viên, quản lý khoa, quản lý môn học: **thêm, sửa, xóa, tìm kiếm**
- Menu chính có thống kê số sinh viên, khoa, môn học, kết quả

## Cách chạy
1. Mở SQL Server Management Studio, chạy `sql/QuanLySinhVien.sql`, sau đó chạy `sql/CapNhat_NguoiDung.sql`.
2. Chép `db.properties.example` thành `db.properties`, sửa `password=` thành mật khẩu `sa` của bạn.
3. Mở Terminal tại thư mục project, chạy `.\chay.bat`.
4. Đăng nhập: `admin` / `123456`.

Yêu cầu: JDK 11 trở lên. Driver JDBC đã có sẵn trong thư mục `lib`.
