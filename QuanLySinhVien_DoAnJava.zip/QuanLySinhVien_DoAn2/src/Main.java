import ui.DangNhapFrame;
import javax.swing.SwingUtilities;

/** Điểm khởi động chương trình: mở form Đăng nhập. */
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(DangNhapFrame::new);
    }
}
