package ui;

import java.sql.*;
import javax.swing.*;
import util.DBConnection;

/** Form 4: Quản lý môn học (thêm, sửa, xóa, tìm kiếm). */
public class MonHocFrame extends CrudFrame {
    private final JTextField txtMa = new JTextField(15);
    private final JTextField txtTen = new JTextField(30);
    private final JTextField txtTC = new JTextField(8);

    public MonHocFrame(MainFrame parent) {
        super(parent, "Quản lý môn học", new String[]{"Mã môn", "Tên môn", "Số tín chỉ"});
        addField("Mã môn (*):", txtMa);
        addField("Tên môn (*):", txtTen);
        addField("Số tín chỉ (*):", txtTC);
        khoiDong(720, 520);
    }

    @Override protected void load(String kw) throws SQLException {
        String sql = "SELECT MaMon, TenMon, SoTinChi FROM MonHoc WHERE MaMon LIKE ? OR TenMon LIKE ? ORDER BY MaMon";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, "%" + kw + "%"); ps.setString(2, "%" + kw + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) model.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getInt(3)});
            }
        }
    }

    @Override protected void onSelect(int r) {
        txtMa.setText(model.getValueAt(r, 0).toString());
        txtTen.setText(model.getValueAt(r, 1).toString());
        txtTC.setText(model.getValueAt(r, 2).toString());
        txtMa.setEditable(false);
    }

    @Override protected void clearForm() { txtMa.setText(""); txtTen.setText(""); txtTC.setText(""); txtMa.setEditable(true); }

    private int tinChi() {
        try {
            int n = Integer.parseInt(bat(txtTC.getText(), "số tín chỉ"));
            if (n <= 0) throw new NumberFormatException();
            return n;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Số tín chỉ phải là số nguyên dương!");
        }
    }

    @Override protected void doInsert() throws Exception {
        String ma = bat(txtMa.getText(), "mã môn"), ten = bat(txtTen.getText(), "tên môn");
        int tc = tinChi();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("INSERT INTO MonHoc(MaMon, TenMon, SoTinChi) VALUES (?, ?, ?)")) {
            ps.setString(1, ma); ps.setString(2, ten); ps.setInt(3, tc); ps.executeUpdate();
        }
    }

    @Override protected void doUpdate() throws Exception {
        if (table.getSelectedRow() < 0) throw new IllegalArgumentException("Hãy chọn một dòng trong bảng để sửa!");
        String ma = bat(txtMa.getText(), "mã môn"), ten = bat(txtTen.getText(), "tên môn");
        int tc = tinChi();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE MonHoc SET TenMon = ?, SoTinChi = ? WHERE MaMon = ?")) {
            ps.setString(1, ten); ps.setInt(2, tc); ps.setString(3, ma); ps.executeUpdate();
        }
    }

    @Override protected void doDelete() throws Exception {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM MonHoc WHERE MaMon = ?")) {
            ps.setString(1, txtMa.getText().trim()); ps.executeUpdate();
        }
    }
}
