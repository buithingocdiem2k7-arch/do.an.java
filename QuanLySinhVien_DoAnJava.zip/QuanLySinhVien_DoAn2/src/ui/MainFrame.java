package ui;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import util.DBConnection;

/** Form 2: Menu chính + thống kê nhanh. */
public class MainFrame extends JFrame {
    private final JLabel lblStat = new JLabel(" ", SwingConstants.CENTER);

    public MainFrame(String hoTen, String vaiTro) {
        setTitle("Quản lý sinh viên");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JLabel title = new JLabel("PHẦN MỀM QUẢN LÝ SINH VIÊN", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(new Color(0, 70, 160));
        JLabel hello = new JLabel("Xin chào: " + hoTen + " (" + vaiTro + ")", SwingConstants.CENTER);
        JPanel north = new JPanel(new GridLayout(3, 1, 0, 5));
        north.setBorder(BorderFactory.createEmptyBorder(15, 10, 5, 10));
        north.add(title); north.add(hello); north.add(lblStat);

        JButton bSV = new JButton("Quản lý sinh viên");
        JButton bKhoa = new JButton("Quản lý khoa");
        JButton bMon = new JButton("Quản lý môn học");
        JButton bOut = new JButton("Đăng xuất");
        JButton bExit = new JButton("Thoát");
        JPanel center = new JPanel(new GridLayout(3, 2, 15, 15));
        center.setBorder(BorderFactory.createEmptyBorder(20, 40, 30, 40));
        for (JButton b : new JButton[]{bSV, bKhoa, bMon, bOut, bExit}) {
            b.setFont(new Font("Arial", Font.PLAIN, 16));
            center.add(b);
        }

        add(north, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);

        bSV.addActionListener(e -> new SinhVienFrame(this));
        bKhoa.addActionListener(e -> new KhoaFrame(this));
        bMon.addActionListener(e -> new MonHocFrame(this));
        bOut.addActionListener(e -> { new DangNhapFrame(); dispose(); });
        bExit.addActionListener(e -> System.exit(0));

        capNhatThongKe();
        setSize(620, 400);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    /** Cập nhật số liệu thống kê (được gọi lại khi đóng các form con). */
    public void capNhatThongKe() {
        try (Connection c = DBConnection.getConnection(); Statement st = c.createStatement()) {
            lblStat.setForeground(new Color(0, 110, 0));
            lblStat.setText("Sinh viên: " + dem(st, "SinhVien") + "   |   Khoa: " + dem(st, "Khoa")
                    + "   |   Môn học: " + dem(st, "MonHoc") + "   |   Kết quả: " + dem(st, "KetQua"));
        } catch (SQLException ex) {
            lblStat.setForeground(Color.RED);
            lblStat.setText("Lỗi kết nối SQL Server: " + ex.getMessage());
        }
    }

    private int dem(Statement st, String bang) throws SQLException {
        try (ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM " + bang)) {
            rs.next();
            return rs.getInt(1);
        }
    }
}
