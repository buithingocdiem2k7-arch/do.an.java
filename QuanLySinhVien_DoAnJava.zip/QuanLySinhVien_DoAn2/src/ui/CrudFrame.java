package ui;

import java.awt.*;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/** Khung chung cho các form quản lý: ô nhập, nút Thêm/Sửa/Xóa/Làm mới, tìm kiếm và bảng dữ liệu. */
abstract class CrudFrame extends JFrame {
    protected final DefaultTableModel model;
    protected final JTable table;
    protected final JTextField txtSearch = new JTextField(18);
    private final JPanel form = new JPanel(new GridBagLayout());
    private int fieldRow = 0;

    CrudFrame(MainFrame parent, String title, String[] columns) {
        setTitle(title);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JLabel lbl = new JLabel(title.toUpperCase(), SwingConstants.CENTER);
        lbl.setFont(new Font("Arial", Font.BOLD, 22));
        lbl.setForeground(new Color(0, 70, 160));
        lbl.setBorder(BorderFactory.createEmptyBorder(10, 0, 5, 0));

        form.setBorder(BorderFactory.createTitledBorder("Thông tin"));

        JButton bAdd = new JButton("Thêm");
        JButton bEdit = new JButton("Sửa");
        JButton bDel = new JButton("Xóa");
        JButton bNew = new JButton("Làm mới");
        JButton bFind = new JButton("Tìm kiếm");
        JPanel tools = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 6));
        tools.add(bAdd); tools.add(bEdit); tools.add(bDel); tools.add(bNew);
        tools.add(new JLabel("Từ khóa:")); tools.add(txtSearch); tools.add(bFind);

        JPanel top = new JPanel(new BorderLayout());
        top.add(lbl, BorderLayout.NORTH);
        top.add(form, BorderLayout.CENTER);
        top.add(tools, BorderLayout.SOUTH);

        model = new DefaultTableModel(columns, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        table.setRowHeight(24);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        add(top, BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) onSelect(table.getSelectedRow());
        });
        bAdd.addActionListener(e -> chay(() -> { doInsert(); }, "Thêm thành công!"));
        bEdit.addActionListener(e -> chay(() -> { doUpdate(); }, "Sửa thành công!"));
        bDel.addActionListener(e -> {
            if (table.getSelectedRow() < 0) { canhBao("Hãy chọn một dòng trong bảng để xóa!"); return; }
            if (JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa dòng này?", "Xác nhận",
                    JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                chay(() -> { doDelete(); }, "Xóa thành công!");
            }
        });
        bNew.addActionListener(e -> { txtSearch.setText(""); clearForm(); table.clearSelection(); refresh(); });
        bFind.addActionListener(e -> refresh());
        txtSearch.addActionListener(e -> refresh());
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override public void windowClosed(java.awt.event.WindowEvent e) { parent.capNhatThongKe(); }
        });
    }

    /** Gọi sau khi subclass đã tạo xong các ô nhập. */
    protected void khoiDong(int w, int h) {
        setSize(w, h);
        setLocationRelativeTo(null);
        refresh();
        setVisible(true);
    }

    protected void addField(String label, JComponent c) {
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 10, 5, 10);
        g.anchor = GridBagConstraints.WEST;
        g.gridx = 0; g.gridy = fieldRow;
        form.add(new JLabel(label), g);
        g.gridx = 1; g.fill = GridBagConstraints.HORIZONTAL; g.weightx = 1;
        form.add(c, g);
        fieldRow++;
    }

    protected void refresh() {
        try {
            model.setRowCount(0);
            load(txtSearch.getText().trim());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi SQL Server: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private interface Viec { void run() throws Exception; }

    private void chay(Viec v, String okMsg) {
        try {
            v.run();
            JOptionPane.showMessageDialog(this, okMsg);
            clearForm();
            refresh();
        } catch (IllegalArgumentException ex) {
            canhBao(ex.getMessage());
        } catch (SQLException ex) {
            String m = ex.getMessage();
            if (ex.getErrorCode() == 2627 || ex.getErrorCode() == 2601) m = "Mã này đã tồn tại, hãy nhập mã khác!";
            else if (ex.getErrorCode() == 547) m = "Không thực hiện được vì dữ liệu đang được bảng khác sử dụng (ràng buộc khóa ngoại).";
            JOptionPane.showMessageDialog(this, m, "Lỗi", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    protected void canhBao(String s) {
        JOptionPane.showMessageDialog(this, s, "Thông báo", JOptionPane.WARNING_MESSAGE);
    }

    /** Ném IllegalArgumentException nếu ô bắt buộc để trống. */
    protected String bat(String giaTri, String ten) {
        if (giaTri == null || giaTri.trim().isEmpty()) throw new IllegalArgumentException("Vui lòng nhập " + ten + "!");
        return giaTri.trim();
    }

    protected abstract void load(String keyword) throws SQLException;
    protected abstract void onSelect(int row);
    protected abstract void clearForm();
    protected abstract void doInsert() throws Exception;
    protected abstract void doUpdate() throws Exception;
    protected abstract void doDelete() throws Exception;
}
