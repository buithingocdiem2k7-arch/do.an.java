package ui;

import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.*;
import util.DBConnection;

/** Form 5: Quản lý sinh viên (thêm, sửa, xóa, tìm kiếm). */
public class SinhVienFrame extends CrudFrame {
    private static final SimpleDateFormat DMY = new SimpleDateFormat("dd/MM/yyyy");
    private final JTextField txtMa = new JTextField(15);
    private final JTextField txtTen = new JTextField(30);
    private final JTextField txtNgay = new JTextField(12);
    private final JComboBox<String> cboGT = new JComboBox<>(new String[]{"Nam", "Nữ"});
    private final JTextField txtDiaChi = new JTextField(30);
    private final JComboBox<String> cboLop = new JComboBox<>();

    public SinhVienFrame(MainFrame parent) {
        super(parent, "Quản lý sinh viên", new String[]{"Mã SV", "Họ tên", "Ngày sinh", "Giới tính", "Địa chỉ", "Lớp"});
        DMY.setLenient(false);
        napLop();
        addField("Mã SV (*):", txtMa);
        addField("Họ tên (*):", txtTen);
        addField("Ngày sinh dd/MM/yyyy (*):", txtNgay);
        addField("Giới tính:", cboGT);
        addField("Địa chỉ:", txtDiaChi);
        addField("Lớp (*):", cboLop);
        khoiDong(900, 640);
    }

    private void napLop() {
        try (Connection c = DBConnection.getConnection(); Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT MaLop FROM Lop ORDER BY MaLop")) {
            while (rs.next()) cboLop.addItem(rs.getString(1));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi tải danh sách lớp: " + ex.getMessage());
        }
    }

    @Override protected void load(String kw) throws SQLException {
        String sql = "SELECT MaSV, HoTen, NgaySinh, GioiTinh, DiaChi, MaLop FROM SinhVien "
                + "WHERE MaSV LIKE ? OR HoTen LIKE ? OR DiaChi LIKE ? OR MaLop LIKE ? ORDER BY MaSV";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 1; i <= 4; i++) ps.setString(i, "%" + kw + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Date d = rs.getDate("NgaySinh");
                    model.addRow(new Object[]{rs.getString("MaSV"), rs.getString("HoTen"),
                        d == null ? "" : DMY.format(d), rs.getString("GioiTinh"),
                        rs.getString("DiaChi"), rs.getString("MaLop")});
                }
            }
        }
    }

    @Override protected void onSelect(int r) {
        txtMa.setText(String.valueOf(model.getValueAt(r, 0)));
        txtTen.setText(String.valueOf(model.getValueAt(r, 1)));
        txtNgay.setText(String.valueOf(model.getValueAt(r, 2)));
        cboGT.setSelectedItem(String.valueOf(model.getValueAt(r, 3)));
        Object dc = model.getValueAt(r, 4);
        txtDiaChi.setText(dc == null ? "" : dc.toString());
        cboLop.setSelectedItem(String.valueOf(model.getValueAt(r, 5)));
        txtMa.setEditable(false);
    }

    @Override protected void clearForm() {
        txtMa.setText(""); txtTen.setText(""); txtNgay.setText(""); txtDiaChi.setText("");
        cboGT.setSelectedIndex(0);
        if (cboLop.getItemCount() > 0) cboLop.setSelectedIndex(0);
        txtMa.setEditable(true);
    }

    private java.sql.Date ngay() {
        try {
            return new java.sql.Date(DMY.parse(bat(txtNgay.getText(), "ngày sinh")).getTime());
        } catch (java.text.ParseException e) {
            throw new IllegalArgumentException("Ngày sinh không hợp lệ, hãy nhập đúng dạng dd/MM/yyyy (ví dụ 12/03/2005)!");
        }
    }

    private String lop() {
        Object o = cboLop.getSelectedItem();
        if (o == null) throw new IllegalArgumentException("Chưa có lớp nào trong cơ sở dữ liệu!");
        return o.toString();
    }

    @Override protected void doInsert() throws Exception {
        String ma = bat(txtMa.getText(), "mã sinh viên"), ten = bat(txtTen.getText(), "họ tên");
        java.sql.Date d = ngay();
        String sql = "INSERT INTO SinhVien(MaSV, HoTen, NgaySinh, GioiTinh, DiaChi, MaLop) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, ma); ps.setString(2, ten); ps.setDate(3, d);
            ps.setString(4, cboGT.getSelectedItem().toString());
            ps.setString(5, txtDiaChi.getText().trim()); ps.setString(6, lop());
            ps.executeUpdate();
        }
    }

    @Override protected void doUpdate() throws Exception {
        if (table.getSelectedRow() < 0) throw new IllegalArgumentException("Hãy chọn một dòng trong bảng để sửa!");
        String ma = bat(txtMa.getText(), "mã sinh viên"), ten = bat(txtTen.getText(), "họ tên");
        java.sql.Date d = ngay();
        String sql = "UPDATE SinhVien SET HoTen = ?, NgaySinh = ?, GioiTinh = ?, DiaChi = ?, MaLop = ? WHERE MaSV = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, ten); ps.setDate(2, d); ps.setString(3, cboGT.getSelectedItem().toString());
            ps.setString(4, txtDiaChi.getText().trim()); ps.setString(5, lop()); ps.setString(6, ma);
            ps.executeUpdate();
        }
    }

    @Override protected void doDelete() throws Exception {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM SinhVien WHERE MaSV = ?")) {
            ps.setString(1, txtMa.getText().trim()); ps.executeUpdate();
        }
    }
}
