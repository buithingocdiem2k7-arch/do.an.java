package ui;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import util.DBConnection;

/** Form 1: Đăng nhập (kiểm tra bảng NguoiDung trong SQL Server). */
public class DangNhapFrame extends JFrame {
    private final JTextField txtUser = new JTextField(18);
    private final JPasswordField txtPass = new JPasswordField(18);
    private final JLabel lblMsg = new JLabel(" ", SwingConstants.CENTER);

    public DangNhapFrame() {
        setTitle("Đăng nhập hệ thống");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        JLabel title = new JLabel("ĐĂNG NHẬP HỆ THỐNG", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setForeground(new Color(0, 70, 160));
        title.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8, 8, 8, 8);
        g.gridx = 0; g.gridy = 0; form.add(new JLabel("Tên đăng nhập:"), g);
        g.gridx = 1; form.add(txtUser, g);
        g.gridx = 0; g.gridy = 1; form.add(new JLabel("Mật khẩu:"), g);
        g.gridx = 1; form.add(txtPass, g);

        JButton btnLogin = new JButton("Đăng nhập");
        JButton btnExit = new JButton("Thoát");
        JPanel btns = new JPanel();
        btns.add(btnLogin); btns.add(btnExit);

        JPanel south = new JPanel(new GridLayout(2, 1));
        south.add(btns); south.add(lblMsg);

        add(title, BorderLayout.NORTH);
        add(form, BorderLayout.CENTER);
        add(south, BorderLayout.SOUTH);

        btnLogin.addActionListener(e -> dangNhap());
        txtPass.addActionListener(e -> dangNhap());
        btnExit.addActionListener(e -> System.exit(0));
        getRootPane().setDefaultButton(btnLogin);

        setSize(430, 290);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void dangNhap() {
        String u = txtUser.getText().trim();
        String p = new String(txtPass.getPassword());
        if (u.isEmpty() || p.isEmpty()) {
            loi("Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu!");
            return;
        }
        String sql = "SELECT HoTen, VaiTro FROM NguoiDung WHERE TenDangNhap = ? AND MatKhau = ?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, u);
            ps.setString(2, p);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    new MainFrame(rs.getString("HoTen"), rs.getString("VaiTro"));
                    dispose();
                } else {
                    loi("Sai tên đăng nhập hoặc mật khẩu!");
                }
            }
        } catch (SQLException ex) {
            loi("Lỗi kết nối SQL Server: " + ex.getMessage());
        }
    }

    private void loi(String s) {
        lblMsg.setForeground(Color.RED);
        lblMsg.setText("<html><center>" + s + "</center></html>");
    }
}
