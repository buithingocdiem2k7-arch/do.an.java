package ui;

import java.sql.*;
import javax.swing.*;
import util.DBConnection;

/** Form 3: Quản lý khoa (thêm, sửa, xóa, tìm kiếm). */
public class KhoaFrame extends CrudFrame {
    private final JTextField txtMa = new JTextField(15);
    private final JTextField txtTen = new JTextField(30);

    public KhoaFrame(MainFrame parent) {
        super(parent, "Quản lý khoa", new String[]{"Mã khoa", "Tên khoa"});
        addField("Mã khoa (*):", txtMa);
        addField("Tên khoa (*):", txtTen);
        khoiDong(700, 480);
    }

    @Override protected void load(String kw) throws SQLException {
        String sql = "SELECT MaKhoa, TenKhoa FROM Khoa WHERE MaKhoa LIKE ? OR TenKhoa LIKE ? ORDER BY MaKhoa";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, "%" + kw + "%"); ps.setString(2, "%" + kw + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) model.addRow(new Object[]{rs.getString(1), rs.getString(2)});
            }
        }
    }

    @Override protected void onSelect(int r) {
        txtMa.setText(model.getValueAt(r, 0).toString());
        txtTen.setText(model.getValueAt(r, 1).toString());
        txtMa.setEditable(false);
    }

    @Override protected void clearForm() { txtMa.setText(""); txtTen.setText(""); txtMa.setEditable(true); }

    @Override protected void doInsert() throws Exception {
        String ma = bat(txtMa.getText(), "mã khoa"), ten = bat(txtTen.getText(), "tên khoa");
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("INSERT INTO Khoa(MaKhoa, TenKhoa) VALUES (?, ?)")) {
            ps.setString(1, ma); ps.setString(2, ten); ps.executeUpdate();
        }
    }

    @Override protected void doUpdate() throws Exception {
        if (table.getSelectedRow() < 0) throw new IllegalArgumentException("Hãy chọn một dòng trong bảng để sửa!");
        String ma = bat(txtMa.getText(), "mã khoa"), ten = bat(txtTen.getText(), "tên khoa");
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE Khoa SET TenKhoa = ? WHERE MaKhoa = ?")) {
            ps.setString(1, ten); ps.setString(2, ma); ps.executeUpdate();
        }
    }

    @Override protected void doDelete() throws Exception {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM Khoa WHERE MaKhoa = ?")) {
            ps.setString(1, txtMa.getText().trim()); ps.executeUpdate();
        }
    }
}
